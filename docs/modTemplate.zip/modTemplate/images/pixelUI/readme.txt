Put your pixel stuff here

You can add pixel notes and pixel countdown sprites



ABOUT PIXEL NOTES:

Name the ENDS the same name of your NOTES, but with "ENDS" at the end of it

For example, if the notes png is called "NOTE_assetsCustom", then name it "NOTE_assetsCustomENDS"