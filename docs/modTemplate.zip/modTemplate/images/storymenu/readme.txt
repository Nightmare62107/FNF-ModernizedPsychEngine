Put your week image here!

MUST be named the same as your week name!