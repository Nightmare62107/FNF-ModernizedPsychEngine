Put your custom charts here



ADDING CREDITS:

You can add a "credits.txt" file to add people to the credits menu

Credits go as follows:

Name::icon::Description::Link::0xFFC6C6C6



ADDING DISCORD SERVERS:

You can add a "servers.txt" file to add servers to the discord menu

Servers go as follows:

Name::Link